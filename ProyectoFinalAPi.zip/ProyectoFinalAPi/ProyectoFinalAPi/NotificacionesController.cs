﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace ProyectoFinalAPi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificacionesController : ControllerBase
    {
        private readonly Cola<Notificacion> _colaNotificaciones;

        public NotificacionesController(Cola<Notificacion> colaNotificaciones)
        {
            _colaNotificaciones = colaNotificaciones;
        }
        [HttpPost]
        public IActionResult EnviarNotificacion([FromBody] Notificacion notificacion)
        {
            try
            {
                _colaNotificaciones.Encolar(notificacion);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Se produjo un error al enviar la notificación.");
            }
        }
        // Método para procesar las notificaciones en la cola
        [HttpPost("procesar")]
        public IActionResult ProcesarNotificacion()
        {
            try
            {
                if (_colaNotificaciones.Count == 0)
                {
                    return BadRequest("No hay notificaciones para procesar.");
                }

                var notificacion = _colaNotificaciones.Desencolar();
                return Ok($"Notificación procesada: {notificacion.Mensaje}");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Se produjo un error al procesar las notificaciones.");
            }
        }
    }
    public class Notificacion
    {
        public int NumeroTarjeta { get; set; }
        public string Mensaje { get; set; }
    }
}