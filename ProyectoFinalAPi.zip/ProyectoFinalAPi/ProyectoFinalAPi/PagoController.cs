﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace ProyectoFinalAPi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PagoController : ControllerBase
    {
        private readonly Cola<Pago> _colaPagos;
        private readonly ListaEnlazada _listaTarjetas;

        public PagoController(Cola<Pago> colaPagos, ListaEnlazada listaTarjetas)
        {
            _colaPagos = colaPagos;
            _listaTarjetas = listaTarjetas;
        }
        [HttpPost]
        public IActionResult RealizarPago([FromBody] Pago pago)
        {
            try
            {
                _colaPagos.Encolar(pago);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Se produjo un error al realizar el pago.");
            }
        }
        // Método para procesar los pagos en la cola
        [HttpPost("procesar")]
        public IActionResult ProcesarPago()
        {
            try
            {
                if (_colaPagos.Count == 0)
                {
                    return BadRequest("No hay pagos para procesar.");
                }
                var pago = _colaPagos.Desencolar();
                _listaTarjetas.ActualizarSaldo(pago.NumeroTarjeta, pago.Monto);
                return Ok("Pago procesado correctamente.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Se produjo un error al procesar los pagos.");
            }
        }
    }
        public class Pago
    {
        public int NumeroTarjeta { get; set; }
        public double Monto { get; set; }
    }
}