﻿using System;

namespace ProyectoFinalAPi
{
    public class ArbolBinarioBusqueda
    {
            public NodoArbol raiz;

            public void Insertar(int valor)
            {
                try
                {
                    raiz = InsertarRecursivo(raiz, valor);
                }
                catch (Exception ex)
                {
                    throw new Exception("Error al insertar en el árbol binario.", ex);
                }
            }

        public NodoArbol InsertarRecursivo(NodoArbol nodo, int valor)
            {
                if (nodo == null)
                {
                    return new NodoArbol(valor);
                }

                if (valor < nodo.Valor)
                {
                    nodo.Izquierda = InsertarRecursivo(nodo.Izquierda, valor);
                }
                else if (valor > nodo.Valor)
                {
                    nodo.Derecha = InsertarRecursivo(nodo.Derecha, valor);
                }

                return nodo;
            }

            public bool Buscar(int valor)
            {
                return BuscarRecursivo(raiz, valor);
            }

        public bool BuscarRecursivo(NodoArbol nodo, int valor)
            {
                if (nodo == null)
                {
                    return false;
                }

                if (valor == nodo.Valor)
                {
                    return true;
                }

                return valor < nodo.Valor ? BuscarRecursivo(nodo.Izquierda, valor) : BuscarRecursivo(nodo.Derecha, valor);
            }

            public void Eliminar(int valor)
            {
                raiz = EliminarRecursivo(raiz, valor);
            }

            private NodoArbol EliminarRecursivo(NodoArbol nodo, int valor)
            {
                if (nodo == null)
                    return nodo;

                if (valor < nodo.Valor)
                    nodo.Izquierda = EliminarRecursivo(nodo.Izquierda, valor);
                else if (valor > nodo.Valor)
                    nodo.Derecha = EliminarRecursivo(nodo.Derecha, valor);
                else
                {
                    if (nodo.Izquierda == null)
                        return nodo.Derecha;
                    else if (nodo.Derecha == null)
                        return nodo.Izquierda;

                    nodo.Valor = MinValor(nodo.Derecha);

                    nodo.Derecha = EliminarRecursivo(nodo.Derecha, nodo.Valor);
                }
                return nodo;
            }

            private int MinValor(NodoArbol nodo)
            {
                int minValor = nodo.Valor;
                while (nodo.Izquierda != null)
                {
                    minValor = nodo.Izquierda.Valor;
                    nodo = nodo.Izquierda;
                }
                return minValor;
            }
        }
    }
