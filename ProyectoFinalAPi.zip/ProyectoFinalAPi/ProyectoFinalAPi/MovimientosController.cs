﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace ProyectoFinalAPi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovimientosController : ControllerBase
    {
        private readonly Pila<Movimiento> pilaMovimientos;

        public MovimientosController(Pila<Movimiento> pilaMovimientos)
        {
            this.pilaMovimientos = pilaMovimientos;
        }

        [HttpGet("{numeroTarjeta}")]
        public IActionResult ConsultarMovimientos(int numeroTarjeta)
        {
            var movimientos = pilaMovimientos.ObtenerTodos(m => m.NumeroTarjeta == numeroTarjeta);
            return Ok(movimientos);
        }
        // Método para registrar nuevos movimientos
        [HttpPost]
        public IActionResult RegistrarMovimiento([FromBody] Movimiento movimiento)
        {
            try
            {
                pilaMovimientos.Apilar(movimiento);
                return Ok("Movimiento registrado correctamente.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Se produjo un error al registrar el movimiento.");
            }
        }
    }
}
