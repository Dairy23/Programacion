﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

[Route("api/[controller]")]
[ApiController]
public class AumentoLimiteController : ControllerBase
{
    private readonly Pila<SolicitudAumento> pilaSolicitudes;
    private readonly List<TarjetaCredito> tarjetas = new List<TarjetaCredito>();

    public AumentoLimiteController(Pila<SolicitudAumento> pilaSolicitudes)
    {
        this.pilaSolicitudes = pilaSolicitudes;
        Initialize();
    }

    private void Initialize()
    {
        try
        {
            tarjetas.Add(new TarjetaCredito { Numero = 1234, Limite = 1000 });
            tarjetas.Add(new TarjetaCredito { Numero = 5678, Limite = 2000 });
            tarjetas.Add(new TarjetaCredito { Numero = 91011, Limite = 1500 });

            throw new Exception("Ocurrió un error al inicializar las tarjetas de crédito.");
        }
        catch (Exception ex)
        {
            // Manejar la excepción aquí, si es necesario
            Console.WriteLine($"Error al inicializar tarjetas de crédito: {ex.Message}");
        }
    }

    // Método para procesar las solicitudes de aumento de límite
    [HttpPost("procesar")]
    public IActionResult Procesar()
    {
        try
        {
            if (pilaSolicitudes.Count == 0)
            {
                return BadRequest("No hay solicitudes de aumento de límite para procesar.");
            }

            var solicitud = pilaSolicitudes.Desapilar();
            var tarjeta = tarjetas.Find(t => t.Numero == solicitud.NumeroTarjeta);
            if (tarjeta != null)
            {
                tarjeta.Limite = solicitud.NuevoLimite;
                return Ok("Solicitud de aumento de límite procesada correctamente.");
            }
            else
            {
                return NotFound("No se encontró la tarjeta de crédito.");
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, "Se produjo un error al procesar las solicitudes de aumento de límite.");
        }
    }
}

public class SolicitudAumento
{
    public int NumeroTarjeta { get; set; }
    public double NuevoLimite { get; set; }
}

public class TarjetaCredito
{
    public int Numero { get; set; }
    public double Limite { get; set; }
}

public class Pila<T>
{
    private Stack<T> elementos = new Stack<T>();
    public void Apilar(T item)
    {
        elementos.Push(item);
    }
    public T Desapilar()
    {
        return elementos.Pop();
    }
    public T Peek()
    {
        return elementos.Peek();
    }
    public int Count
    {
        get { return elementos.Count; }
    }
}
