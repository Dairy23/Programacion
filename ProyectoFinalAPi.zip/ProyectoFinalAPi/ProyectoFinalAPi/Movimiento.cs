﻿namespace ProyectoFinalAPi
{
    public class Movimiento
    {
        public int NumeroTarjeta { get; set; }
        public string Tipo { get; set; }
        public double Monto { get; set; }
    }
}