﻿using System.Text.Json;

namespace ProyectoFinalAPi
{
    public class JSON
    {
        public List<TarjetaCredito> CargarTarjetasDesdeJSON(string jsonFilePath)
        {
            try
            {
                // Leer el contenido del archivo JSON
                string jsonContent = File.ReadAllText(jsonFilePath);

                // Deserializar el contenido JSON en una lista de objetos de TarjetaCredito
                List<TarjetaCredito> tarjetas = JsonSerializer.Deserialize<List<TarjetaCredito>>(jsonContent);

                // Devolver la lista de tarjetas cargadas desde el archivo JSON
                return tarjetas;
            }
            catch (Exception ex)
            {
                // Manejar cualquier excepción que pueda ocurrir durante la carga del archivo JSON
                Console.WriteLine($"Error al cargar las tarjetas desde el archivo JSON: {ex.Message}");
                return new List<TarjetaCredito>(); // Devolver una lista vacía en caso de error
            }
        }
    }
}