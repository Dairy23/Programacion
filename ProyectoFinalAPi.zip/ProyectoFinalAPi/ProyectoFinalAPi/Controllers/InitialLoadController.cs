﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;

public class InitialLoadController : ControllerBase
{
    [HttpPost("load")]
    public IActionResult LoadInitialData()
    {
        try
        {
            string jsonFileName = "datos_tarjetas.json";
            if (!System.IO.File.Exists(jsonFileName))
            {
                return StatusCode(500, "El archivo datos_tarjetas.json no se encontró en la ruta especificada.");
            }
            string jsonContent = System.IO.File.ReadAllText(jsonFileName);
            List<TarjetaCredito> tarjetas = JsonSerializer.Deserialize<List<TarjetaCredito>>(jsonContent);

            // Aquí puedes agregar las tarjetas a tus estructuras de datos

            return Ok("Datos iniciales cargados con éxito.");
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Error al cargar los datos iniciales: {ex.Message}");
        }
    }
}