﻿//Dairy Pernillo 
//Programacion 
//Proyecto Final. 

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using ProyectoFinalAPi;

public class Startup
{
    public void ConfigureServices(IServiceCollection services)
    {
        services.AddScoped<ListaEnlazada>();
        services.AddSingleton<ArbolBinarioBusqueda>(); // Registrar ArbolBinarioBusqueda como un servicio singleton
        services.AddMvc();
        services.AddControllers();
        services.AddSingleton<Pila<SolicitudAumento>>();


        // Configuración de Swagger
        services.AddSwaggerGen(options =>
        {
            options.SwaggerDoc("v1", new OpenApiInfo { Title = "Tarjeta de Credito", Version = "v1" });
        });
    }

    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {

        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }

        app.UseHttpsRedirection();

        app.UseRouting();

        app.UseAuthorization();

        // Habilitar Swagger y SwaggerUI
        app.UseSwagger();
        app.UseSwaggerUI(options =>
        {
            options.SwaggerEndpoint("/swagger/v1/swagger.json", "Tarjeta de Credito");
        });

        app.UseEndpoints(endpoints =>
        {
            endpoints.MapControllers();
        });
    }
}