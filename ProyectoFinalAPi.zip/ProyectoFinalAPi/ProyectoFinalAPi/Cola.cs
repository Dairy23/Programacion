﻿using System.Collections.Generic;

namespace ProyectoFinalAPi
{
    public class Cola<T>
    {
        private Queue<T> elementos = new Queue<T>();

        public void Encolar(T item)
        {
            elementos.Enqueue(item);
        }
        public T Desencolar()
        {
            return elementos.Dequeue();
        }

        public T Peek()
        {
            return elementos.Peek();
        }

        public int Count
        {
            get { return elementos.Count; }
        }
    }
}