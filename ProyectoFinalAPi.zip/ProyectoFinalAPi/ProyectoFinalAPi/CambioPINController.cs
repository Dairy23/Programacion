﻿using Microsoft.AspNetCore.Mvc;
using ProyectoFinalAPi;

[Route("api/[controller]")]
[ApiController]
public class CambioPINController : ControllerBase
{
    private readonly ListaEnlazada _listaTarjetas;

    public CambioPINController(ListaEnlazada listaTarjetas)
    {
        _listaTarjetas = listaTarjetas;
    }

    [HttpPost("{numeroTarjeta}")]
    public IActionResult CambiarPIN(int numeroTarjeta, [FromBody] int nuevoPIN)
    {
        try
        {
            // Validación manual de los datos de entrada
            if (nuevoPIN.ToString().Length != 4)
            {
                return BadRequest("El nuevo PIN debe tener 4 dígitos.");
            }

            _listaTarjetas.CambiarPIN(numeroTarjeta, nuevoPIN);
            return Ok("PIN cambiado correctamente.");
        }
        catch (Exception ex)
        {
            return StatusCode(500, "Se produjo un error al cambiar el PIN de la tarjeta.");
        }
    }
}

    public class CambioPIN
{
    public int NumeroTarjeta { get; set; }
    public int NuevoPIN { get; set; }
}
