﻿using Microsoft.AspNetCore.Mvc;
using ProyectoFinalAPi;

[Route("api/[controller]")]
[ApiController]
public class BloqueoTemporalController : ControllerBase
{
    public readonly ArbolBinarioBusqueda arbolBloqueos;
    public readonly ArbolBinarioBusqueda arbolBinario;

    public BloqueoTemporalController(ArbolBinarioBusqueda arbolBinario, ArbolBinarioBusqueda arbolBloqueos)
    {
        arbolBloqueos = arbolBloqueos;
        arbolBinario = arbolBinario;
    }

    [HttpPost("bloquear")]
    public IActionResult BloquearTarjeta([FromBody] BloqueoTemporal bloqueo)
    {
        try
        {
            arbolBloqueos.Insertar(bloqueo.NumeroTarjeta);
            return Ok();
        }
        catch (Exception ex)
        {
            return StatusCode(500, "Se produjo un error al bloquear la tarjeta.");
        }
    }

    [HttpPost("desbloquear")]
    public IActionResult DesbloquearTarjeta([FromBody] BloqueoTemporal bloqueo)
    {
        try
        {
            arbolBloqueos.Eliminar(bloqueo.NumeroTarjeta);
            return Ok();
        }
        catch (Exception ex)
        {
            return StatusCode(500, "Se produjo un error al desbloquear la tarjeta.");
        }
    }

    [HttpDelete("{valor}")]
    public IActionResult EliminarValor(int valor)
    {
        try
        {
            arbolBinario.Eliminar(valor);
            return Ok("Valor eliminado correctamente.");
        }
        catch (Exception ex)
        {
            return StatusCode(500, "Se produjo un error al eliminar el valor del árbol binario.");
        }
    }
}

    public class BloqueoTemporal
{
    public int NumeroTarjeta { get; set; }
}