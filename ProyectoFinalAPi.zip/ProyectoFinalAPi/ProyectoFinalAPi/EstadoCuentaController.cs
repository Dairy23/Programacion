﻿using Microsoft.AspNetCore.Mvc;
using ProyectoFinalAPi;
using System.Collections.Generic;

[Route("api/[controller]")]
[ApiController]
public class EstadoCuentaController : ControllerBase
{
    private readonly ArbolBinarioBusqueda _arbolEstadosCuenta;

    public EstadoCuentaController(ArbolBinarioBusqueda arbolEstadosCuenta)
    {
        _arbolEstadosCuenta = arbolEstadosCuenta;
    }

    [HttpGet("{numeroTarjeta}")]
    public IActionResult GenerarEstadoCuenta(int numeroTarjeta)
    {
        try
        {
            var estadoCuenta = _arbolEstadosCuenta.Buscar(numeroTarjeta);
            if (estadoCuenta == null)
                return NotFound();
            return Ok(estadoCuenta);
        }
        catch (Exception ex)
        {
            return StatusCode(500, "Se produjo un error al generar el estado de cuenta.");
        }
    }
}
