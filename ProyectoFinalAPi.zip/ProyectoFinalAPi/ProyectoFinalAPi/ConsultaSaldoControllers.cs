﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace ProyectoFinalAPi
{
    [Route("api/[controller]")]
    [ApiController]
    public class ConsultaSaldoControllers : ControllerBase
    {
        private readonly ListaEnlazada listaTarjetas;

        public ConsultaSaldoControllers(ListaEnlazada listaTarjetas)
        {
            this.listaTarjetas = listaTarjetas;
        }

        [HttpGet("saldo/{numeroTarjeta}")]
        public IActionResult ConsultarSaldo(int numeroTarjeta)
        {
            var saldo = listaTarjetas.ConsultarSaldo(numeroTarjeta);
            if (saldo == -1)
                return NotFound();
            return Ok(saldo);
        }

        [HttpGet("tarjetas")]
        public IActionResult ObtenerTarjetas()
        {
            var listaTarjetas = new List<TarjetaCredito>();
            listaTarjetas.Add(new TarjetaCredito { NumeroTarjeta = 1234, Saldo = 100.00 });
            listaTarjetas.Add(new TarjetaCredito { NumeroTarjeta = 5678, Saldo = 200.00 });

            return Ok(listaTarjetas);
        }

        // Método para actualizar el saldo de una tarjeta después de una transacción
        [HttpPost("actualizar/{numeroTarjeta}")]
        public IActionResult ActualizarSaldo(int numeroTarjeta, [FromBody] double nuevoSaldo)
        {
            try
            {
                listaTarjetas.ActualizarSaldo(numeroTarjeta, nuevoSaldo);
                return Ok("Saldo actualizado correctamente.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Se produjo un error al actualizar el saldo de la tarjeta.");
            }
        }
    }
}
