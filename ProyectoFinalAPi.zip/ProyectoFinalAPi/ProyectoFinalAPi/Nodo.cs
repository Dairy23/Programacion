﻿namespace ProyectoFinalAPi
{
    public class NodoArbol
    {
        public int NumeroTarjeta { get; set; }
        public double Saldo { get; set; }
        public int Valor { get; set; }
        public NodoArbol Izquierda { get; set; }
        public NodoArbol Derecha { get; set; }

        public NodoArbol(int valor)
        {
            Valor = valor;
            Izquierda = null;
            Derecha = null;
        }

    }
}