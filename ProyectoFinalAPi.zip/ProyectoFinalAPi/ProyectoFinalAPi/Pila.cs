﻿using System.Collections.Generic;
using System.Linq;

namespace ProyectoFinalAPi
{
    public class Pila<T>
    {
        private Stack<T> elementos = new Stack<T>();

        public void Apilar(T elemento)
        {
            elementos.Push(elemento);
        }

        public T Desapilar()
        {
            return elementos.Pop();
        }

        public T Peek()
        {
            return elementos.Peek();
        }

        public List<T> ObtenerTodos(Func<T, bool> predicado)
        {
            return elementos.Where(predicado).ToList();
        }

        public int Count
        {
            get { return elementos.Count; }
        }

        public List<T> ConsultarMovimientos()
        {
            return new List<T>(elementos);
        }
    }
}